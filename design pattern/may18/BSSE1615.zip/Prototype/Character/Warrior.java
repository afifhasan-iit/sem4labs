package Prototype.Character;
/*2. Character Creation in a Game
A game development studio is creating a fantasy role-playing game where players can select character
classes such as Warrior, Mage, Archer, and Assassin. Each character requires complex initialization
involving animations, weapons, armor, sound effects, abilities, and skill trees. During development, the
programmers notice that creating every character from scratch requires substantial memory and
processing time because many characters share similar configurations. For example, multiple enemy
warriors may use the same animations and equipment with only slight variations in health or attack
power.
The central prototype class is GameCharacter, which stores shared character data through attributes
such as name, health, weapon, armor, skillSet, and animationProfile. The class also
defines methods like clone(), attack(), move(), and displayCharacterInfo(). Specialized
subclasses such as Warrior, Mage, and Archer extend the base prototype while introducing their
own unique methods. For example, Warrior may contain equipSword() and shieldBlock(),
while Mage may implement castSpell() and manaRecharge(). A CharacterFactory class may
control the cloning process using methods such as createEnemy(), createBoss(), and
spawnNPC(). Instead of repeatedly initializing every character from the beginning, the system clones
existing prototypes and modifies only selected attributes like weapon type, health level, or abilities.
*/
public class Warrior extends GameCharacter {

    public Warrior(String name, int health, String weapon, String armor, java.util.List<String> skillSet, String animationProfile) {
        super(name, health, weapon, armor, skillSet, animationProfile);
    }

    public Warrior(Warrior target) {
        super(target);
    }

    @Override
    public GameCharacter clone() {
        return new Warrior(this);
    }

    public void useShield() {
        System.out.println(getName() + " uses shield to block incoming attack!");
    }

    public void equipSword() {
        System.out.println(getName() + " equips a sword for close combat!");
    }

    public void equipShield() {
        System.out.println(getName() + " equips a shield for defense!");
    }

    public int getHealth() {
        return super.getHealth();
    }

    
}
